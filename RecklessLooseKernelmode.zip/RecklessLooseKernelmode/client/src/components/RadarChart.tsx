import Plot from "react-plotly.js";
import type { Data, Layout, Config } from "plotly.js";

interface RadarChartProps {
  labels: string[];
  values: number[];
}

export default function RadarChart({ labels, values }: RadarChartProps) {
  const wrappedLabels = labels.map((label) => {
    const words = label.split(" ");
    const lines: string[] = [];
    let currentLine = "";
    
    words.forEach((word) => {
      if (currentLine.length + word.length > 15) {
        lines.push(currentLine.trim());
        currentLine = word;
      } else {
        currentLine += (currentLine ? " " : "") + word;
      }
    });
    if (currentLine) lines.push(currentLine.trim());
    
    return lines.join("<br>");
  });

  const data: Data[] = [
    {
      type: "scatterpolar",
      r: [...values, values[0]],
      theta: [...wrappedLabels, wrappedLabels[0]],
      fill: "toself",
      fillcolor: "rgba(99, 102, 241, 0.2)",
      line: {
        color: "rgb(99, 102, 241)",
        width: 2,
      },
      marker: {
        color: "rgb(99, 102, 241)",
        size: 10,
      },
      name: "Pain Points",
      hoverinfo: "text",
      text: labels.map((label, i) => `${label}<br>Score: ${values[i]}`),
    },
  ];

  const layout: Partial<Layout> = {
    polar: {
      radialaxis: {
        visible: true,
        range: [0, 55],
        tickfont: {
          family: "Inter, system-ui, sans-serif",
          size: 10,
          color: "#6b7280",
        },
        gridcolor: "#e5e7eb",
        linecolor: "#e5e7eb",
        angle: 90,
      },
      angularaxis: {
        tickfont: {
          family: "Inter, system-ui, sans-serif",
          size: 11,
          color: "#1f2937",
        },
        gridcolor: "#e5e7eb",
        linecolor: "#e5e7eb",
        rotation: 90,
        direction: "clockwise",
      },
      bgcolor: "transparent",
    },
    showlegend: false,
    margin: { t: 80, r: 100, b: 80, l: 100 },
    paper_bgcolor: "transparent",
    font: {
      family: "Inter, system-ui, sans-serif",
    },
    autosize: true,
  };

  const config: Partial<Config> = {
    responsive: true,
    displayModeBar: false,
  };

  return (
    <div
      className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm p-6"
      data-aos="fade-in"
      data-aos-duration="600"
    >
      <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
        Pain Points Distribution
      </h3>
      <div className="w-full h-[480px]" data-testid="chart-radar">
        <Plot
          data={data}
          layout={layout}
          config={config}
          style={{ width: "100%", height: "100%" }}
          useResizeHandler
        />
      </div>
    </div>
  );
}
