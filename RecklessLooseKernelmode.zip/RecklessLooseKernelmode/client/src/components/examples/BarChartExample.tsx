import BarChart from "../BarChart";

// todo: remove mock functionality
const mockData = {
  labels: [
    "Connectivity & software issues",
    "Comfort & fit problems",
    "ANC side-effects",
    "Price & value concerns",
    "Build quality issues",
  ],
  values: [47, 42, 38, 33, 31],
};

export default function BarChartExample() {
  return <BarChart labels={mockData.labels} values={mockData.values} />;
}
