import { useEffect, useRef } from "react";
import AOS from "aos";
import "aos/dist/aos.css";
import html2canvas from "html2canvas";
import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import RadarChart from "./RadarChart";
import BarChart from "./BarChart";
import WordCloud from "./WordCloud";
import InsightCard from "./InsightCard";

// todo: remove mock functionality - hardcoded data
const painPointsData = {
  labels: [
    "Connectivity & software issues",
    "Comfort & fit problems",
    "ANC side-effects (pressure, popping, artifacts)",
    "Price & value concerns",
    "Build quality, durability & design flaws",
  ],
  values: [47, 42, 38, 33, 31],
};

// todo: remove mock functionality - sample keywords for word cloud
const wordCloudData = [
  { text: "Bluetooth", size: 60 },
  { text: "Battery", size: 52 },
  { text: "Comfort", size: 48 },
  { text: "Sound Quality", size: 55 },
  { text: "Price", size: 42 },
  { text: "Durability", size: 38 },
  { text: "Noise Cancellation", size: 50 },
  { text: "Connectivity", size: 45 },
  { text: "Design", size: 35 },
  { text: "Latency", size: 32 },
];

function generateInsights(labels: string[], values: number[]) {
  const maxIndex = values.indexOf(Math.max(...values));
  const minIndex = values.indexOf(Math.min(...values));
  const average = values.reduce((a, b) => a + b, 0) / values.length;

  return {
    topConcern: {
      label: labels[maxIndex],
      value: values[maxIndex],
    },
    lowestConcern: {
      label: labels[minIndex],
      value: values[minIndex],
    },
    averageScore: average.toFixed(1),
  };
}

export default function Dashboard() {
  const dashboardRef = useRef<HTMLDivElement>(null);
  const insights = generateInsights(painPointsData.labels, painPointsData.values);

  useEffect(() => {
    AOS.init({
      once: true,
      easing: "ease-in-out",
    });
  }, []);

  const handleDownload = async () => {
    if (!dashboardRef.current) return;

    try {
      const canvas = await html2canvas(dashboardRef.current, {
        backgroundColor: "#f9fafb",
        scale: 2,
        useCORS: true,
        logging: false,
      });

      const link = document.createElement("a");
      link.download = "pain-points-dashboard.png";
      link.href = canvas.toDataURL("image/png");
      link.click();
    } catch (error) {
      console.error("Failed to download dashboard:", error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      <div ref={dashboardRef} className="max-w-7xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
        <header className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-12">
          <div>
            <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-gray-100 tracking-tight">
              Pain Points Analysis
            </h1>
            <p className="text-gray-500 dark:text-gray-400 mt-2">
              Customer feedback insights and trends
            </p>
          </div>
          <Button
            variant="outline"
            onClick={handleDownload}
            className="gap-2 self-start sm:self-auto"
            data-testid="button-download"
          >
            <Download className="w-4 h-4" />
            Download PNG
          </Button>
        </header>

        <section className="mb-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div data-aos="fade-up" data-aos-delay="0">
              <InsightCard
                type="top"
                value={insights.topConcern.label.split(" ")[0]}
                label="Top Concern"
                subtext={`Score: ${insights.topConcern.value}`}
              />
            </div>
            <div data-aos="fade-up" data-aos-delay="100">
              <InsightCard
                type="lowest"
                value={insights.lowestConcern.label.split(" ")[0]}
                label="Lowest Concern"
                subtext={`Score: ${insights.lowestConcern.value}`}
              />
            </div>
            <div data-aos="fade-up" data-aos-delay="200">
              <InsightCard
                type="average"
                value={insights.averageScore}
                label="Average Score"
                subtext="Across all categories"
              />
            </div>
          </div>
        </section>

        <section className="mb-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <RadarChart labels={painPointsData.labels} values={painPointsData.values} />
            <BarChart labels={painPointsData.labels} values={painPointsData.values} />
          </div>
        </section>

        <section>
          <WordCloud words={wordCloudData} />
        </section>
      </div>
    </div>
  );
}
