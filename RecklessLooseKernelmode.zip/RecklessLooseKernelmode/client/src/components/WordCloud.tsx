import { useEffect, useRef, useState } from "react";
import cloud from "d3-cloud";

interface WordInput {
  text: string;
  size: number;
}

interface LayoutWord {
  text: string;
  size: number;
  x: number;
  y: number;
  rotate: number;
  font: string;
}

interface WordCloudProps {
  words: WordInput[];
}

export default function WordCloud({ words }: WordCloudProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [layoutWords, setLayoutWords] = useState<LayoutWord[]>([]);
  const [dimensions, setDimensions] = useState({ width: 800, height: 400 });

  useEffect(() => {
    if (!containerRef.current) return;

    const updateDimensions = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        setDimensions({
          width: rect.width || 800,
          height: 400,
        });
      }
    };

    updateDimensions();
    window.addEventListener("resize", updateDimensions);
    return () => window.removeEventListener("resize", updateDimensions);
  }, []);

  useEffect(() => {
    const layout = cloud<WordInput>()
      .size([dimensions.width, dimensions.height])
      .words(words.map((w) => ({ ...w })))
      .padding(8)
      .rotate(() => (Math.random() > 0.5 ? 0 : 90 * (Math.random() > 0.5 ? 1 : -1)))
      .font("Inter, system-ui, sans-serif")
      .fontSize((d) => d.size || 20)
      .spiral("archimedean")
      .on("end", (computedWords) => {
        setLayoutWords(
          computedWords.map((w: any) => ({
            text: w.text || "",
            size: w.size || 20,
            x: w.x || 0,
            y: w.y || 0,
            rotate: w.rotate || 0,
            font: w.font || "Inter",
          }))
        );
      });

    layout.start();
  }, [words, dimensions]);

  const colors = [
    "#818cf8",
    "#a78bfa",
    "#c4b5fd",
    "#ddd6fe",
    "#e0e7ff",
    "#c7d2fe",
    "#a5b4fc",
    "#93c5fd",
    "#7dd3fc",
    "#67e8f9",
  ];

  return (
    <div
      ref={containerRef}
      className="bg-gray-900 dark:bg-gray-950 rounded-xl p-8 md:p-12"
      data-aos="fade-in"
      data-aos-duration="600"
      data-aos-delay="200"
    >
      <h3 className="text-lg font-semibold text-white mb-6">
        Trending Keywords
      </h3>
      <svg
        width="100%"
        height={dimensions.height}
        viewBox={`0 0 ${dimensions.width} ${dimensions.height}`}
        preserveAspectRatio="xMidYMid meet"
        data-testid="wordcloud-svg"
      >
        <g transform={`translate(${dimensions.width / 2}, ${dimensions.height / 2})`}>
          {layoutWords.map((word, i) => (
            <text
              key={`${word.text}-${i}`}
              textAnchor="middle"
              transform={`translate(${word.x}, ${word.y}) rotate(${word.rotate})`}
              style={{
                fontSize: `${word.size}px`,
                fontFamily: word.font,
                fontWeight: word.size > 40 ? 600 : 400,
                fill: colors[i % colors.length],
                transition: "all 0.3s ease",
                cursor: "default",
              }}
              className="hover:opacity-80"
            >
              {word.text}
            </text>
          ))}
        </g>
      </svg>
    </div>
  );
}
