import WordCloud from "../WordCloud";

// todo: remove mock functionality
const mockWords = [
  { text: "Bluetooth", size: 60 },
  { text: "Battery", size: 52 },
  { text: "Comfort", size: 48 },
  { text: "Sound Quality", size: 55 },
  { text: "Price", size: 42 },
  { text: "Durability", size: 38 },
  { text: "Noise Cancellation", size: 50 },
  { text: "Connectivity", size: 45 },
  { text: "Design", size: 35 },
  { text: "Latency", size: 32 },
];

export default function WordCloudExample() {
  return <WordCloud words={mockWords} />;
}
