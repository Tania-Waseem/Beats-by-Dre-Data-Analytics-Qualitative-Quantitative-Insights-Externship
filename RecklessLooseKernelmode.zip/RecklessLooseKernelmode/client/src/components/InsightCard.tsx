import { TrendingUp, TrendingDown, BarChart3 } from "lucide-react";

type InsightType = "top" | "lowest" | "average";

interface InsightCardProps {
  type: InsightType;
  value: string;
  label: string;
  subtext?: string;
}

const iconMap = {
  top: TrendingUp,
  lowest: TrendingDown,
  average: BarChart3,
};

const colorMap = {
  top: {
    border: "border-l-indigo-500",
    icon: "text-indigo-500",
    bg: "bg-indigo-50 dark:bg-indigo-950/30",
  },
  lowest: {
    border: "border-l-emerald-500",
    icon: "text-emerald-500",
    bg: "bg-emerald-50 dark:bg-emerald-950/30",
  },
  average: {
    border: "border-l-violet-500",
    icon: "text-violet-500",
    bg: "bg-violet-50 dark:bg-violet-950/30",
  },
};

export default function InsightCard({ type, value, label, subtext }: InsightCardProps) {
  const Icon = iconMap[type];
  const colors = colorMap[type];

  return (
    <div
      className={`bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm p-6 pl-5 border-l-4 ${colors.border} transition-shadow duration-200 hover:shadow-md`}
      data-aos="fade-up"
      data-aos-duration="600"
      data-testid={`insight-card-${type}`}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">
            {label}
          </p>
          <p className="text-2xl font-bold text-gray-900 dark:text-gray-100 truncate">
            {value}
          </p>
          {subtext && (
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              {subtext}
            </p>
          )}
        </div>
        <div className={`p-3 rounded-lg ${colors.bg}`}>
          <Icon className={`w-5 h-5 ${colors.icon}`} />
        </div>
      </div>
    </div>
  );
}
