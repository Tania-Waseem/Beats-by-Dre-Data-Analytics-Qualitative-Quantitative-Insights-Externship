import InsightCard from "../InsightCard";

export default function InsightCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-4">
      <InsightCard
        type="top"
        value="Connectivity"
        label="Top Concern"
        subtext="Score: 47"
      />
      <InsightCard
        type="lowest"
        value="Build"
        label="Lowest Concern"
        subtext="Score: 31"
      />
      <InsightCard
        type="average"
        value="38.2"
        label="Average Score"
        subtext="Across all categories"
      />
    </div>
  );
}
