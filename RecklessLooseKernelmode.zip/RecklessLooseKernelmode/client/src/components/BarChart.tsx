import Plot from "react-plotly.js";
import type { Data, Layout, Config } from "plotly.js";

interface BarChartProps {
  labels: string[];
  values: number[];
}

export default function BarChart({ labels, values }: BarChartProps) {
  const colors = [
    "rgb(99, 102, 241)",
    "rgb(168, 85, 247)",
    "rgb(20, 184, 166)",
    "rgb(245, 158, 11)",
    "rgb(239, 68, 68)",
  ];

  const wrappedLabels = labels.map((label) => {
    const words = label.split(" ");
    const lines: string[] = [];
    let currentLine = "";
    
    words.forEach((word) => {
      if (currentLine.length + word.length > 20) {
        lines.push(currentLine.trim());
        currentLine = word;
      } else {
        currentLine += (currentLine ? " " : "") + word;
      }
    });
    if (currentLine) lines.push(currentLine.trim());
    
    return lines.join("<br>");
  });

  const data: Data[] = [
    {
      type: "bar",
      x: values,
      y: wrappedLabels,
      orientation: "h",
      marker: {
        color: colors,
      },
      hovertemplate: "%{y}<br>Score: %{x}<extra></extra>",
      text: values.map((v) => v.toString()),
      textposition: "outside",
      textfont: {
        family: "Inter, system-ui, sans-serif",
        size: 13,
        color: "#374151",
      },
    },
  ];

  const layout: Partial<Layout> = {
    xaxis: {
      range: [0, Math.max(...values) * 1.25],
      tickfont: {
        family: "Inter, system-ui, sans-serif",
        size: 11,
        color: "#6b7280",
      },
      gridcolor: "#f3f4f6",
      linecolor: "#e5e7eb",
      zeroline: false,
    },
    yaxis: {
      tickfont: {
        family: "Inter, system-ui, sans-serif",
        size: 12,
        color: "#1f2937",
      },
      automargin: true,
      gridcolor: "#f3f4f6",
      linecolor: "#e5e7eb",
      tickangle: 0,
    },
    margin: { t: 20, r: 50, b: 50, l: 200 },
    paper_bgcolor: "transparent",
    plot_bgcolor: "transparent",
    font: {
      family: "Inter, system-ui, sans-serif",
    },
    showlegend: false,
    bargap: 0.35,
    autosize: true,
  };

  const config: Partial<Config> = {
    responsive: true,
    displayModeBar: false,
  };

  return (
    <div
      className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm p-6"
      data-aos="fade-in"
      data-aos-duration="600"
      data-aos-delay="100"
    >
      <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
        Comparative Analysis
      </h3>
      <div className="w-full h-[420px]" data-testid="chart-bar">
        <Plot
          data={data}
          layout={layout}
          config={config}
          style={{ width: "100%", height: "100%" }}
          useResizeHandler
        />
      </div>
    </div>
  );
}
